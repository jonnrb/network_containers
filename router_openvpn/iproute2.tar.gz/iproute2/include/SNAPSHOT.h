static const char SNAPSHOT[] = "161212";
